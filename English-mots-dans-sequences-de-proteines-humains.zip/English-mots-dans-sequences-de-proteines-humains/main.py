import  words_in_proteome
#liste des mots
listMot=words_in_proteome.read_words("english-common-words.txt")
print(listMot)
print("nombre de words",len(listMot))
#sequence de protéine
dictSeq=words_in_proteome.read_sequences("human-proteome.fasta")
print("nombre de sequence =",len(dictSeq))
print("sequence de proteine O95139 : ",words_in_proteome.read_sequences("human-proteome.fasta")['O95139'])
#mot dans protéine occurence dans séquence
print("dictionnaire nb mots ")
dictNB=words_in_proteome.search_words_in_proteome(listMot,dictSeq)
for k,val in dictNB.items():
   print(k,"FOUND IN ",val,"Sequences")
#max d'occurence de mots dans les séquences de protéine
dictMax =words_in_proteome.find_most_frequent_word(dictNB)
for k,max in dictMax.items():
   print("maxx",k ,"found in ",max, "sequences")
   print ("pourcentage d'apparition ",(max/len(dictSeq)*100),"%")
#occurence de mots dans protéine plus complet
print("search_words_in_proteome_plus_complet")
dictNB2=words_in_proteome.search_words_in_proteome_plus_complet(listMot,dictSeq)
dictMax2=words_in_proteome.find_most_frequent_word(dictNB2)
for k,max in dictMax2.items():
   print("maxx",k ,"found in ",max, "sequences")



